package main

import (
	"encoding/csv"
	"encoding/xml"
	"fmt"
	"io"
	"io/ioutil"
	"log"
	"os"
)

type Data struct {
	BMOfile []Manifest `xml:"Manifest",omitempty`
}

type Manifest struct {
	Header  *Header  `xml:"Header"`
	Package *Package `xml:"Package"`
}

type Package struct {
	EswShipmentReference             string     `xml:"EswShipmentReference"`
	CustomerReference                string     `xml:"CustomerReference"`
	CarrierReference                 string     `xml:"CarrierReference"`
	BrandOrderReference              string     `xml:"BrandOrderReference"`
	ServiceLevel                     string     `xml:"ServiceLevel"`
	Weight                           string     `xml:"Weight"`
	WeightUnit                       string     `xml:"WeightUnit"`
	VolumetricWeight                 string     `xml:"VolumetricWeight"`
	ShippingValue                    string     `xml:"ShippingValue"`
	ShippingValueDuty                string     `xml:"ShippingValueDuty"`
	ShippingValueVat                 string     `xml:"ShippingValueVat"`
	ShippingValueCurrencyCode        string     `xml:"ShippingValueCurrencycode"`
	GoodsDescription                 string     `xml:"GoodsDescription"`
	GoodsValue                       string     `xml:"GoodsValue"`
	GoodsValueDuty                   string     `xml:"GoodsValueDuty"`
	GoodsValueVat                    string     `xml:"GoodsValueVat"`
	GoodsValueCurrencyCode           string     `xml:"GoodsValueCurrencyCode"`
	DutyTaxHandlingValue             string     `xml:"DutyTaxHandlingValue"`
	DutyTaxHandlingValueCurrencyCode string     `xml:"DutyTaxHandlingValueCurrencyCode"`
	Piece                            string     `xml:"Piece"`
	TotalPieces                      string     `xml:"TotalPieces"`
	CountryOfOrigin                  string     `xml:"CountryOfOrigin"`
	Shipper                          *Shipper   `xml:"Shipper"`
	Consignee                        *Consignee `xml:"Consignee"`
	Incoterm                         string     `xml:"Incoterm"`
	DistributionCentre               string     `xml:"DistributionCentre"`
	Hold                             string     `xml:"Hold"`
	PackageDimensionsHeight          string     `xml:"PackageDimensionsHeight"`
	PackageDimensionsWidth           string     `xml:"PackageDimensionWidth"`
	PackageDimensionsLength          string     `xml:"PackageDimensionsLenght"`
	PackageDimensionsUnit            string     `xml:"PackageDimensionsUnit"`
	CODValue                         string     `xml:"CODValue"`
	CODValueCurrencyCode             string     `xml:"CODValueCurrencyCode"`
	PUDO                             string     `xml:"PUDO"`
	OrderPaymentId                   string     `xml:"OrderPaymentId"`
	OrderPaymentValue                string     `xml:"OrderPaymentValue"`
	OrderPaymentValueCurrencyCode    string     `xml:"OrderPaymentValueCurrencyCode"`
	EswOrderDate                     string     `xml:"EswOrderDate"`
	EswPackageShippedDate            string     `xml:"EswPackageShippedDate"`
	ContainsDangerousGoods           string     `xml:"ContainsDangerousGoods"`
	InsuranceValue                   string     `xml:"InsuranceValue"`
	AdditionalImportInformation      string     `xml:"AdditionalImportInformation"`
	Item                             *Item      `xml:"Item"`
}

type Header struct {
	Version            string `xml:"Version"`
	AccountNumber      string `xml:"AccountNumber"`
	PackageCount       string `xml:"PackageCount"`
	FileCreateDateTime string `xml:"FileCreateDateTime"`
	TimeZone           string `xml:"TimeZone"`
	Filename           string `xml:"Filename"`
}

type Shipper struct {
	Name       string `xml:"Name"`
	Address1   string `xml:"Address1"`
	Address2   string `xml:"Address2",omitempty`
	City       string `xml:"City"`
	Region     string `xml:"Region"`
	PostalCode string `xml:"PostalCode"`
	Country    string `xml:"Country"`
	Telephone  string `xml:"Telephone"`
	Email      string `xml:"Email"`
}

type Consignee struct {
	ConsigneeDetails *ConsigneeDetails `xml:"ConsigneeDetails"`
	ConsigneePUDO    string            `xml:"ConsigneePUDO"`
	Identification   string            `xml:"Identification"`
}

type ConsigneeDetails struct {
	Name       string `xml:"Name"`
	Address1   string `xml:"Address1"`
	Address2   string `xml:"Address2",omitempty`
	City       string `xml:"City"`
	Region     string `xml:"Region",omitempty`
	PostalCode string `xml:"PostalCode",omitempty`
	Country    string `xml:"Country"`
	Telephone  string `xml:"Telephone"`
	Email      string `xml:"Email"`
}

type Item struct {
	Description           string `xml:"Description"`
	CustomsDescription    string `xml:"CustomsDescription"`
	Quantity              string `xml:"Quantity"`
	UnitPrice             string `xml:"UnitPrice"`
	UnitPriceDuty         string `xml:"UnitPriceDuty"`
	UnitPriceVat          string `xml:"UnitPriceVat"`
	UnitShippingValue     string `xml:"UnitShippingValue"`
	UnitShippingValueDuty string `xml:"UnitShippingValueDuty"`
	UnitShippingValueVat  string `xml:"UnitShippingValueVat"`
	Currency              string `xml:"Currency"`
	CountryOfOrigin       string `xml:"CountryOfOrigin"`
	HsCode                string `xml:"HsCode"`
	ProductCode           string `xml:"ProductCode"`
	ItemWeight            string `xml:"ItemWeight"`
	WeightUnit            string `xml:"WeightUnit"`
	ProductDescriptionURL string `xml:"ProductDescriptionURL"`
	FTA                   string `xml:"FTA"`
	DangerousGoods        string `xml:"DangerousGoods"`
}

func main() {
	csvFile, _ := os.Open("BMO_File1.csv")
	reader := csv.NewReader(csvFile)
	var note []Manifest
	for {
		line, error := reader.Read()
		if error == io.EOF {
			break
		} else if error != nil {
			log.Fatal(error)
		}
		note = append(note, Manifest{
			Header: &Header{
				Version:            line[0],
				AccountNumber:      line[1],
				PackageCount:       line[2],
				FileCreateDateTime: line[3],
				TimeZone:           line[4],
				Filename:           line[5],
			},
			Package: &Package{
				EswShipmentReference:             line[6],
				CustomerReference:                line[7],
				CarrierReference:                 line[8],
				BrandOrderReference:              line[9],
				ServiceLevel:                     line[10],
				Weight:                           line[11],
				WeightUnit:                       line[12],
				VolumetricWeight:                 line[13],
				ShippingValue:                    line[14],
				ShippingValueDuty:                line[15],
				ShippingValueVat:                 line[16],
				ShippingValueCurrencyCode:        line[17],
				GoodsDescription:                 line[18],
				GoodsValue:                       line[19],
				GoodsValueDuty:                   line[20],
				GoodsValueVat:                    line[21],
				GoodsValueCurrencyCode:           line[22],
				DutyTaxHandlingValue:             line[23],
				DutyTaxHandlingValueCurrencyCode: line[24],
				Piece:                            line[25],
				TotalPieces:                      line[26],
				CountryOfOrigin:                  line[27],
				Shipper: &Shipper{
					Name:       line[28],
					Address1:   line[29],
					Address2:   line[30],
					City:       line[31],
					Region:     line[32],
					PostalCode: line[33],
					Country:    line[34],
					Telephone:  line[35],
					Email:      line[36],
				},
				Consignee: &Consignee{
					ConsigneeDetails: &ConsigneeDetails{
						Name:       line[37],
						Address1:   line[38],
						Address2:   line[39],
						City:       line[40],
						Region:     line[41],
						PostalCode: line[42],
						Country:    line[43],
						Telephone:  line[44],
						Email:      line[45],
					},
					ConsigneePUDO:  line[46],
					Identification: line[47],
				},
				Incoterm:                      line[48],
				DistributionCentre:            line[49],
				Hold:                          line[50],
				PackageDimensionsHeight:       line[51],
				PackageDimensionsWidth:        line[52],
				PackageDimensionsLength:       line[53],
				PackageDimensionsUnit:         line[54],
				CODValue:                      line[55],
				CODValueCurrencyCode:          line[56],
				PUDO:                          line[57],
				OrderPaymentId:                line[58],
				OrderPaymentValue:             line[59],
				OrderPaymentValueCurrencyCode: line[60],
				EswOrderDate:                  line[61],
				EswPackageShippedDate:         line[62],
				ContainsDangerousGoods:        line[63],
				InsuranceValue:                line[64],
				AdditionalImportInformation:   line[65],
				Item: &Item{
					Description:           line[66],
					CustomsDescription:    line[67],
					Quantity:              line[68],
					UnitPrice:             line[69],
					UnitPriceDuty:         line[70],
					UnitPriceVat:          line[71],
					UnitShippingValue:     line[72],
					UnitShippingValueDuty: line[73],
					UnitShippingValueVat:  line[74],
					Currency:              line[75],
					CountryOfOrigin:       line[76],
					HsCode:                line[77],
					ProductCode:           line[78],
					ItemWeight:            line[79],
					WeightUnit:            line[80],
					ProductDescriptionURL: line[81],
					FTA:                   line[82],
					DangerousGoods:        line[83],
				},
			},
		})
	}
	if file, err := xml.MarshalIndent(note, "", " "); err == nil {
		file = []byte(xml.Header + string(file))
		fmt.Printf("%s\n", file)
		err = ioutil.WriteFile("notes6.xml", file, 0644)
	}
}
